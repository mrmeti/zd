﻿--اپن شده توسط نویسنده سورس (@Mr_Kourd19)
TD_ID =  1219147672 -- ایدی عددی ربات پاکسازی
Sudoid = 1900060993 --ایدی عددی مالک ربات
BotHelper = 5034071891 --ایدی عددی توکن
UserBotHelper = '@fjgjrigibot'--یوزرنیم ربات
token = '5034071891:AAEshtJVw83BXEhhwdoL6GpVc-fFGk3GeVE'--توکن ربات
rediscode = '1'--شماره ردیس
Sudo = 'Metiwz'--یوزرنیم مالک
ChannelInline = 'Metiwz_Team'--یوزرنیم کانال
----لطفا منبع را پاک نکنید 
--Cr : @Mr_kourd19
--Ch : @LeaderUpdate
--التماس دعا